---------------------------------------------------------------
Template Details
---------------------------------------------------------------

Template Name : GreatMag Blogger Template

Template Author : Lasantha Bandara (http://www.premiumbloggertemplates.com/)

Configuration Details : http://www.premiumbloggertemplates.com/greatmag-blogger-template/

---------------------------------------------------------------


Template Installation 

1.First download the template and unzip the file. 

2.Now, sign in to Blogger dashboard and click on the layout.

3.Here is the important step, after uploading any new Blogger template, all of the previous widgets like your google adsense ads,text,profile,poll,etc etc will be lost.
So, to avoid this to happen, in this step click on 'edit' on all the widgets and copy the codes into notepad,etc.

4.Now click on the 'Edit html' tab

5.First of all please Download Full Template.This is to back up your present template.If the new template that you are going to upload makes/gets into some errors or if you make more complex errors in that,then you will loose everthing.So make sure that you back up your template.

6.Just below that,there's an option of uploading new template.So, use the Browse button and upload the downloaded xml file.

7.Now, a message appear saying that your widgets are about to be deleted.Click on the Confirm & Save (no problem doing this because we already copied the widget codes in Step 3).

8.Now click on "confirm and save".Now you successfully installed the template.

8.Click on the 'Page elements' page now and add the codes that you copied in step3 using the 'Add a Page Element' option.


-------------------------------------------------------------------------------------------------------
PREMIUM SERVICES
-------------------------------------------------------------------------------------------------------


You can get premium services from PremiumBloggerTemplates.com :


1.Design your Blog (Price Starting From: $ 75.00 USD)

Do you want to create a unique blogger template for your blog.Do you have many ideas for a blog?Tell me your ideas.Then I can create a great premium blogger template for you.You will certainly get satisfied!!!



2.Convert Wordpress to Blogger (Price Starting From: $ 50.00 USD)

Do you want to convert a wordpress theme to blogger to add it for your blog?I can do it for you.Just send me your wordpress theme and I will return the blogger version of that theme.



3.Convert PSD / JPG / GIF to Blogger Layout (Price Starting From: $ 50.00 US)

Just send me your Images files and I will convert it into a great unique blogger template just for you!



4.Customize Your Blog (Price Starting From: $ 20.00 US)

This service include to customizable your own blog, for example:
If you want to change some features of your current blogger template such as add another sidebar, split header,create footer,change header image, background image, slider for featured posts, change post content width etc.


Do You have so many Ideas for a blog? But don't know how to make it? Tell me what you want! I will work hard to make a really great blog design for you. You will certainly get satisfied!


Contact me : btipandtrick@gmail.com

http://www.premiumbloggertemplates.com/2010/06/premium-services-premiumbloggertemplate.html
------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------




-----------------------------------------------
Term of use
-----------------------------------------------

All free Blogger templates on WWW.PREMIUMBLOGGERTEMPLATES.COM are licensed under the Creative Commons Attribution 3.0 License,which permits both personal and commercial use.
However, to satisfy the 'attribution' clause of the license, you are required to keep the footer links intact which provides due credit to its authors. For more specific details about the license, you may visit the URL below:
http://creativecommons.org/licenses/by/3.0/

------------------------------------------------


Lasantha Bandara

http://www.premiumbloggertemplates.com/



Blogger Tips And Tricks:

http://www.bloggertipandtrick.net/